echo "I'm yet ANOTHER bash script!"

declare PY.BASHIFY_EXECUTE=testing.script

echo "I'm another bash script!"

declare testing.another_script

# Let's say this is the main one
declare testing.script

declare BASHIFY_EXECUTE

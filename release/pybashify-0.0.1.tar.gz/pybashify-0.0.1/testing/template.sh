echo "I'm a bash script!"

declare BASHIFY_EXECUTE="testing.script"

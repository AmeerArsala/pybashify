import sys


print(f"Python Version: {sys.version}")
